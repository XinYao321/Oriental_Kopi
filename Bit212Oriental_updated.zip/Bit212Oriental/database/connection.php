<?php

// Retrieve database configuration from environment variables
$host = getenv('DB_HOST') ?: 'localhost';
$port = getenv('DB_PORT') ?: 3306;
$database = getenv('DB_DATABASE') ?: 'products';
$username = getenv('DB_USERNAME') ?: 'root';
$password = getenv('DB_PASSWORD') ?: '';

// Establish a new MySQLi connection
$conn = new mysqli($host, $username, $password, $database, $port);

// Check for connection errors
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
} 
/**else {
    echo "Connection successful!";
}**/

// Close the connection when done (optional)
// $conn->close();

?>
