<?php
require_once './database/connection.php';
define('URL', 'https://' . $_SERVER['SERVER_NAME'] . '/');
function version($name){
    return(filemtime($_SERVER['DOCUMENT_ROOT'] .$name));
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $created_at = date('Y-m-d'); // current date in 'yyyy-mm-dd' format
    $imagePath = '';

    // Check if a file is uploaded without any error
if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
    $imageDir = './upload/';

    // Generate a unique name for the image file to prevent conflicts
    $imagePath = $imageDir . uniqid() . '-' . basename($_FILES['image']['name']);
    
    // Move the uploaded file to the 'upload' directory
    move_uploaded_file($_FILES['image']['tmp_name'], $imagePath);
}


    // Prepare the SQL query and insert data without PDO
    $query = "INSERT INTO product (name, price, image_path, created_at) VALUES ('$name', '$price', '$imagePath', '$created_at')";
    
    if ($conn->query($query) === TRUE) {
        echo "<div class='alert alert-success text-center'>New product added successfully!</div>";
    } else {
        echo "<div class='alert alert-danger text-center'>Error: " . $conn->error . "</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Add New Product</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav onclick="window.location = 'home.php'" style="cursor: pointer;" class="text-uppercase container-fluid text-center text-light py-3 font-weight-bold">Oriental Kopi</nav>
    <div class="container mt-4">
        <h2 class="text-center">Add New Product</h2>
        <form action="addNewItem.php" method="POST" enctype="multipart/form-data" class="mt-4">
            <div class="form-group">
                <label for="image">Product Image:</label>
                <input type="file" class="form-control-file" name="image" accept="image/*" required>
            </div>
            
            <div class="form-group">
                <label for="name">Product Name:</label>
                <input type="text" class="form-control" name="name" placeholder="Enter product name" required>
            </div>
            
            <div class="form-group">
                <label for="price">Product Price:</label>
                <input type="text" class="form-control" name="price" placeholder="Enter product price" required>
            </div>
            
            <button type="submit" class="btn btn-primary btn-block">Create Item</button>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js"></script>
</body>
</html>
