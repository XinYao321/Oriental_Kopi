<?php
require_once './database/connection.php';
define('URL', 'https://' . $_SERVER['SERVER_NAME'] . '/');
header('Content-Type: application/json');

// Helper function for error response
function sendError($message) {
    echo json_encode(['error' => $message]);
    exit();
}

// GET Request - Fetch products
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $id = $_GET['id'] ?? null;
    $sql = $id ? "SELECT * FROM product WHERE id = ?" : "SELECT * FROM product";
    $stmt = $conn->prepare($sql);

    if ($id) {
        $stmt->bind_param('i', $id); // Bind id parameter safely
    }
    $stmt->execute();
    $result = $stmt->get_result();

    $products = [];
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
    echo json_encode($products ?: ['error' => 'No products found.']);
}

// PUT Request - Update product
if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    parse_str(file_get_contents("php://input"), $parsedData);
    $id = $parsedData['id'] ?? null;
    $name = $parsedData['name'] ?? null;
    $price = $parsedData['price'] ?? null;

    if (!$id || !$name || !$price) {
        sendError("Invalid data provided.");
    }

    $sql = "UPDATE product SET name = ?, price = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('sdi', $name, $price, $id);

    if ($stmt->execute()) {
        echo json_encode(['success' => 'Product updated successfully.']);
    } else {
        sendError("Failed to update product.");
    }
}

// DELETE Request - Delete product
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    $id = $_GET['id'] ?? null;

    if (!$id) {
        sendError("Product ID is required.");
    }

    $sql = "DELETE FROM product WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $id);

    if ($stmt->execute()) {
        echo json_encode(['success' => 'Product deleted successfully.']);
    } else {
        sendError("Failed to delete product.");
    }
}

// POST Request - Add new product
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $conn->real_escape_string($_POST['name'] ?? '');
    $price = $conn->real_escape_string($_POST['price'] ?? '');
    if (!$name || !$price || empty($_FILES["image"]["name"])) {
        sendError("All product fields are required.");
    }

    // File upload handling
    $targetDir = $_SERVER["DOCUMENT_ROOT"] . "/uploads/";
    $fileName = basename($_FILES["image"]["name"]);
    $targetFilePath = $targetDir . $fileName;
    $imageFileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));
    $imageURL = URL . "uploads/" . $fileName;

    // Validate image
    $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
    $fileSize = $_FILES["image"]["size"];
    if ($fileSize > 500000 || !in_array($imageFileType, $allowedTypes)) {
        sendError("File is either too large or not an allowed format.");
    }

    // Move file and save product info
    if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFilePath)) {
        $sql = "INSERT INTO product (name, price, image_path, created_at) VALUES (?, ?, ?, NOW())";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('sds', $name, $price, $imageURL);

        if ($stmt->execute()) {
            echo json_encode(['success' => 'Product added successfully']);
        } else {
            sendError("Error adding product: " . $conn->error);
        }
    } else {
        sendError("File upload failed.");
    }
}

?>
