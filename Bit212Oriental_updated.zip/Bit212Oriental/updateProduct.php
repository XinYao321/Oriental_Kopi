<?php
require_once './database/connection.php';
define('URL', 'https://' . $_SERVER['SERVER_NAME'] . '/');

// Get the product ID from the URL
$productID = isset($_GET['productId']) ? $_GET['productId'] : null;

// Initialize variables for product data
$productName = '';
$productPrice = '';
$productImage = '';

// Fetch product details from the database
if ($productID) {
    $stmt = $conn->prepare("SELECT name, price, image_path FROM product WHERE id = ?");
    $stmt->bind_param("i", $productID);
    $stmt->execute();
    $stmt->bind_result($productName, $productPrice, $productImage);
    $stmt->fetch();
    $stmt->close();
}

// Update product details if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['updateProduct'])) {
    $newName = $_POST['name'];
    $newPrice = $_POST['price'];

    $stmt = $conn->prepare("UPDATE product SET name = ?, price = ? WHERE id = ?");
    $stmt->bind_param("sdi", $newName, $newPrice, $productID);
    if ($stmt->execute()) {
        $productName = $newName;
        $productPrice = $newPrice;
        $message = "Product updated successfully.";
    } else {
        $message = "Error updating product.";
    }
    $stmt->close();
}

// Delete product if confirmed through the modal
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['confirmDelete'])) {
    $stmt = $conn->prepare("DELETE FROM product WHERE id = ?");
    $stmt->bind_param("i", $productID);
    if ($stmt->execute()) {
        header("Location: home.php"); // Redirect to home after deletion
        exit();
    } else {
        $message = "Error deleting product.";
    }
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Oriental Kopi - Product Details</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav onclick="window.location = 'home.php'" style="cursor: pointer;" class="text-uppercase container-fluid text-center text-light py-3 font-weight-bold">Oriental Kopi</nav>

    <div class="content-details">
        <div class="category text-uppercase">
            Product Details
        </div>
        <?php if (isset($message)) echo "<p class='text-success'>$message</p>"; ?>
        <div class="productDetails" id="productDetails">
            <div class="updateProduct flex flex-col" id="<?php echo $productID; ?>">
                <img class="productImage" src="<?php echo htmlspecialchars($productImage); ?>" alt="<?php echo htmlspecialchars($productName); ?>">
                <span class="text-pretty truncate" id="productNameLabel"><?php echo htmlspecialchars($productName); ?></span>
                <span class="text-pretty truncate" id="productPriceLabel">RM<?php echo htmlspecialchars($productPrice); ?></span>
            </div>
        </div>

        <form method="POST" action="updateProduct.php?productId=<?php echo $productID; ?>" style="display:flex; flex-direction:column; width:150px; margin-top:20px;">
            <div style="margin-block:5px;">
                <label for="name">Product Name:</label>
                <input type="text" id="updateName" name="name" style="margin-block:5px; border-radius:10px; text-align:center;" value="<?php echo htmlspecialchars($productName); ?>" required />
            </div>
            <div style="margin-block:5px;">
                <label for="price">Product Price (RM):</label>
                <input type="number" id="updatePrice" name="price" style="margin-block:5px; border-radius:10px; text-align:center;" value="<?php echo htmlspecialchars($productPrice); ?>" required />
            </div>
            <button class="update-button btn btn-primary" type="submit" name="updateProduct">Save</button>
        </form>

        <!-- Delete Button and Modal Trigger -->
        <button class="delete-button btn btn-danger" type="button" onclick="showDeleteModal()">Delete Item</button>

        <!-- Delete Confirmation Modal -->
        <div class="deleteModalDark" style="display:none;">
            <div class="deletemodal">
                <div class="modal-head text-center">
                    <h4>Are you sure?</h4>
                </div>
                <div class="modal-body">
                    Delete <span id="productNameModal"><?php echo htmlspecialchars($productName); ?></span>
                </div>
                <div class="buttonsModal">
                    <button id="modalCancel" onclick="hideDeleteModal()">Cancel</button>
                    <form method="POST" style="display:inline;">
                        <button type="submit" name="confirmDelete" id="modalDelete">Delete</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

    <script>
        // Show the delete confirmation modal
        function showDeleteModal() {
            document.querySelector('.deleteModalDark').style.display = 'block';
        }

        // Hide the delete confirmation modal
        function hideDeleteModal() {
            document.querySelector('.deleteModalDark').style.display = 'none';
        }

        // Close modal if clicking outside the modal
        document.querySelector('.deleteModalDark').addEventListener('click', function(event) {
            if (!event.target.closest('.deletemodal')) {
                hideDeleteModal();
            }
        });
    </script>
</body>
</html>
