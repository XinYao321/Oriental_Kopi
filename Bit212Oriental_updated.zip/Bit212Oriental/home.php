<?php
require_once './database/connection.php';
define('URL', 'https://' . $_SERVER['SERVER_NAME'] . '/');

function version($name) {
    return filemtime($_SERVER['DOCUMENT_ROOT'] . $name);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Oriental Kopi</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    
    <nav onclick="window.location = 'home.php'" style="cursor: pointer;" class="text-uppercase container-fluid text-center text-light py-3 font-weight-bold">Oriental Kopi</nav>
    <div class="category text-uppercase">
        Signature Menu
    </div>
    <div class="container-fluid">
        <div class="grid grid-col-4" id="productList">
            <?php
            // Query to fetch products from the database
            $sql = "SELECT id, name, price, image_path FROM product";
            $result = $conn->query($sql);

            // Check if there are products and display them
            if ($result && $result->num_rows > 0) {
                while ($product = $result->fetch_assoc()) {
                    echo '<div class="product flex flex-col" id="' . $product['id'] . '">';
                    echo '<img class="productImage" src="' . htmlspecialchars($product['image_path']) . '" alt="' . htmlspecialchars($product['name']) . '">';
                    echo '<span class="text-pretty truncate">' . htmlspecialchars($product['name']) . '</span>';
                    echo '<span class="text-pretty truncate">RM' . htmlspecialchars($product['price']) . '</span>';
                    echo '<a href="updateProduct.php?productId=' . $product['id'] . '" class="btn btn-link">Update Product</a>';
                    echo '</div>';
                }
            } else {
                echo '<p>No products found.</p>';
            }
            $conn->close();
            ?>
        </div>
    </div>

    <div class="button">
        <button class="add-button" style="margin-bottom: 50px;" type="button" onclick="addNewItem()">Add New Item</button>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

    <script>
        function addNewItem() {
            location.href = "addNewItem.php";
        }
    </script>
</body>
</html>
